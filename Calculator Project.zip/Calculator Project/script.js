// Select elements
const result = document.getElementById('result');
const history = document.getElementById('history');
const buttons = document.querySelectorAll('.btn');
const clearBtn = document.getElementById('clear');
const equalsBtn = document.getElementById('equals');
const toggleTheme = document.getElementById('toggleTheme');
const body = document.body;

let currentInput = '';
let calculationHistory = '';

// Add button click events
buttons.forEach(button => {
    button.addEventListener('click', () => {
        const value = button.getAttribute('data-value');

        if (!value) return; // Skip if no data-value
        currentInput += value;
        result.value = currentInput;
    });
});

// Clear button
clearBtn.addEventListener('click', () => {
    currentInput = '';
    result.value = '';
});

// Equals button
equalsBtn.addEventListener('click', () => {
    if (currentInput === '') return;
    try {
        const calculation = eval(currentInput); // simple eval for demo
        history.textContent = currentInput + ' = ' + calculation;
        currentInput = calculation;
        result.value = currentInput;
    } catch (error) {
        result.value = 'Error';
    }
});

// Theme toggle
toggleTheme.addEventListener('click', () => {
    body.classList.toggle('dark');
});
